# Phase 7 deployment notes

## Goal
Keep the production site on a single canonical destination for the root entry points:
- http://diwansuite.com/ -> https://diwansuite.com/ar
- http://www.diwansuite.com/ -> https://diwansuite.com/ar
- https://diwansuite.com/ -> https://diwansuite.com/ar
- https://www.diwansuite.com/ -> https://diwansuite.com/ar

## What is already generated in dist
- .htaccess
- robots.txt
- sitemap.xml and localized sitemap files
- redirect-map.csv
- error pages: 404.html, 500.html, 503.html

## Mandatory deployment rules
1. Upload the full dist folder contents to public_html.
2. Make sure the generated .htaccess replaces any old root redirect rules.
3. Remove or disable conflicting cPanel Redirects rules that force:
   - http -> https on the root first
   - www -> non-www in a separate hop
   - / -> /ar in a second hop
4. In Cloudflare, avoid stacking a separate Always Use HTTPS or Bulk Redirect rule that causes:
   - http://diwansuite.com/ -> https://diwansuite.com/ -> https://diwansuite.com/ar
5. Keep exactly one canonical root destination: https://diwansuite.com/ar

## Live verification after deployment
Run:

node scripts/check-live-redirects.mjs

Expected result:
- each root variant finishes in at most 1 redirect hop before the final 200
- final URL is always https://diwansuite.com/ar

## Rollback
- restore the previous .htaccess only if the new upload breaks localized routes
- do not restore any old redirect manager rule that creates a second hop on the root

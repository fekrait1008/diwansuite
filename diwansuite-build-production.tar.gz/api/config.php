<?php
/**
 * Diwan Suite - Configuration File
 * 
 * IMPORTANT: This file contains sensitive credentials.
 * - DO NOT commit this file to version control
 * - Set proper file permissions (chmod 600)
 */

return [
    // ============================================
    // SMTP CONFIGURATION
    // ============================================
    'smtp' => [
        'host'      => 'smtp.gmail.com',
        'port'      => 587,
        'username'  => 'no-replay@fekrait.com.sa',
        'password'  => 'ascslsprczpyvxiy',
        'encryption'=> 'tls',
        'from_email'=> 'no-replay@fekrait.com.sa',
        'from_name' => 'Diwan Suite',
    ],
    
    // ============================================
    // EMAIL RECIPIENTS
    // ============================================
    'recipients' => [
        'to'  => 'info@fekrait.com.sa',
        'cc'  => [],
        'bcc' => [],
    ],
    
    // ============================================
    // RECAPTCHA CONFIGURATION
    // ============================================
    'recaptcha' => [
        'enabled'    => true,
        'site_key'   => '6LfOI8gsAAAAAA6SN7IyZnso-nI0jJTNGfM1e-JE',
        'secret_key' => '6LfOI8gsAAAAAI6M7thcjYHYdWamU82IfaChiujH',
        'min_score'  => 0.5,
    ],
    
    // ============================================
    // CRM INTEGRATION (EightGate)
    // ============================================
    'crm' => [
        'enabled'  => true,
        'api_url'  => 'https://eightgate.ws/ecm/api/v3/post/1',
        'api_key'  => 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNzg4M2RmZDBiOGU2YjFiOTU1ZTFkYmYxYTJjYWIzZWM2ZWQ0OGNmYjJkNDcyZmU0ZjQyMzlhZDE3ODNmNDE1YWU3MGU2YTBmZGVmODVkYTkiLCJpYXQiOjE3MzM2NjU1NzYuOTgyMjQyMTA3MzkxMzU3NDIxODc1LCJuYmYiOjE3MzM2NjU1NzYuOTgyMjQ0MDE0NzM5OTkwMjM0Mzc1LCJleHAiOjE3NjUyMDE1NzYuOTgwNDM5OTAxMzUxOTI4NzEwOTM3NSwic3ViIjoiMTYiLCJzY29wZXMiOltdfQ.jM2K9AFv3v-JiiYMy8m3h5ZD5QkokNCPxdJr5vHQxucvkbWceLTZeSLPICuAbwt6_GjblZjOJ0R5ZF9NiWGuvh4ZuDBOsEGUrvr8TURs7iNh-2CsnyCT28Vk_nWKVphAGDdM9QHegufl1MNIxd_cma6nPNpCQ-0cVMD5pyaXBVfF74d6izseCkh4KX2TubGUqAOHpvgBc391PW9kmrJXjIVPVumdmOt2Agsi6PUhv1sz9Vq7kQ0kErkZvuTC4-fssbUjnk-4G7zG8T30A3VkBYuxZcdq6P-_N6JAq2o81RlnBe2wKg8GaWJ1r1zuzJAXUZpVYGWuKKCJYycBbzVuVwV_DtuVkliDfkpazmvsTX0z1I-utUAI7BnzcoQC2oyJOoxGjE6ZaNTbSCbZKX51GMqOP9mwm3qqlz3oyKGL7DsYVUZ6pASI-i0KsH7KyEGZgdFyEVjX00MnLW5jVdryLLGK38-cdwLDXKwYo0yjKRiJDnB_6fBJ_jNFEuFHYa6RG2oMKoOAfHytLwmA3Rcpb4zgy0P1SITKYxffnwAFbOKEWi2S2GVG1h04_PUgF3WAoSSSVi_GmQegmNJt72wPgDywXsYfXnG0NwurXhbhpESPPujmGkUAhSEWlt2N2lGfXf5Jj1-eHBKeSYM_nYcAIEgEH9nNI_lw9GSODPrMrVE',
        'timeout'  => 10,
    ],
    
    // ============================================
    // SECURITY
    // ============================================
    'security' => [
        'rate_limit_enabled' => true,
        'rate_limit_max'     => 5,
        'allowed_origins'    => [
            'https://diwansuite.com',
            'https://www.diwansuite.com',
            'http://localhost:4173',
            'http://localhost:3000',
        ],
    ],
    
    // ============================================
    // NOTIFICATIONS (OPTIONAL)
    // ============================================
    'notifications' => [
        'slack_webhook'   => '',
        'telegram_bot'    => '',
        'telegram_chat'   => '',
    ],
];

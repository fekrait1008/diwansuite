Good. Do not rebuild and do not modify code now.

Provide exact final verification for the existing artifact only.

==================================================
1) ZIP VERIFICATION
==================================================

Verify the existing ZIP:

cpanel-deploy.zip

Confirm exact ZIP path and size.

List whether the ZIP contains:

- index.html
- assets/
- sitemap.xml
- robots.txt
- .htaccess
- api/contact.php
- api/health.php
- api/lib/contact-security.php
- api/lib/config.php
- api/config.example.php if present

Important:
You said the ZIP excludes "server-side files".
Clarify whether PHP API files are included or excluded.
For cPanel deployment, PHP API files must be included.

==================================================
2) DANGEROUS FILE CHECK
==================================================

Confirm the ZIP and dist do NOT contain:

- .env
- node_modules
- public/api/config.php
- api/config.php with real secrets
- SMTP passwords
- CRM tokens
- reCAPTCHA secret values
- diwan_leads/
- source files
- tests

If api/lib/config.php exists, confirm:
- it uses environment variables or safe placeholders only
- it contains no real credentials
- it is safe to deploy

==================================================
3) DIST CONFIRMATION
==================================================

Confirm exact existence:

- dist/index.html:
- dist/assets:
- dist/sitemap.xml:
- dist/robots.txt:
- dist/.htaccess:
- dist/api/contact.php:
- dist/api/health.php:
- dist/api/lib/contact-security.php:
- dist/api/lib/config.php:
- dist/api/config.example.php:
- dist/api/config.php:

==================================================
4) HERO FIX CONFIRMATION FROM SOURCE
==================================================

Confirm:

- Hero file changed:
- The grid/container uses direction: ltr:
- Inner Arabic text content keeps direction: rtl:
- Inner Arabic text aligns right:
- Arabic desktop final logic: image LEFT / text RIGHT:
- English/LTR impact: not broken

==================================================
5) COMMAND RESULTS
==================================================

Provide the last command results:

- npm run typecheck:
- npm run build:
- npm run test:
- npm run --if-present check:seo-aeo:
- npm run --if-present check:links:

Do not rerun unless the result is not available.

==================================================
6) FINAL DECISION
==================================================

Use only one:

- READY — CPANEL ZIP VERIFIED
- NOT READY — CPANEL ZIP BLOCKERS FOUND
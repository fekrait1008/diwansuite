<?php
/**
 * DiwanSuite API Configuration Example
 * 
 * INSTRUCTIONS:
 * 1. Copy this file to config.php
 * 2. Fill in your actual credentials below
 * 3. Upload config.php to your server (do NOT commit to git)
 * 
 * SECURITY WARNING:
 * - Never commit config.php with real credentials to version control
 * - Keep config.php outside public_html if possible
 * - Set file permissions to 640 or 600
 */

return [
    // ======================
    // Database Configuration
    // ======================
    'db' => [
        'host'     => 'localhost',
        'name'     => 'your_database_name',      // e.g., 'cpanel_user_diwansuite'
        'user'     => 'your_database_user',      // e.g., 'cpanel_user_dbuser'
        'password' => 'your_database_password',  // Strong password
        'charset'  => 'utf8mb4',
        'port'     => 3306,
    ],

    // ======================
    // Email Configuration (SMTP)
    // ======================
    'mail' => [
        'smtp_host'     => 'mail.yourdomain.com',   // Your SMTP server
        'smtp_port'     => 587,                      // Usually 587 (TLS) or 465 (SSL)
        'smtp_secure'   => 'tls',                    // 'tls' or 'ssl'
        'smtp_user'     => 'noreply@yourdomain.com', // SMTP username
        'smtp_password' => 'your_smtp_password',     // SMTP password
        'from_email'    => 'noreply@yourdomain.com', // From address
        'from_name'     => 'DiwanSuite',             // From name
        'to_email'      => 'info@yourdomain.com',    // Where to receive contact form emails
        'to_name'       => 'DiwanSuite Team',        // Recipient name
    ],

    // ======================
    // Security Settings
    // ======================
    'security' => [
        // CSRF token secret (generate a random 32+ character string)
        'csrf_secret'     => 'CHANGE_THIS_TO_A_RANDOM_32_CHAR_STRING',
        
        // Rate limiting
        'rate_limit'      => 5,      // Max requests per window
        'rate_window'     => 3600,   // Window in seconds (1 hour)
        
        // Honeypot field name (change to something unique)
        'honeypot_field'  => 'website_url',
        
        // Allowed origins for CORS (your domain)
        'allowed_origins' => [
            'https://yourdomain.com',
            'https://www.yourdomain.com',
        ],
    ],

    // ======================
    // Application Settings
    // ======================
    'app' => [
        'name'        => 'DiwanSuite',
        'environment' => 'production',  // 'development' or 'production'
        'debug'       => false,         // Set to true only for debugging
        'timezone'    => 'Asia/Dubai',  // Your timezone
        'locale'      => 'ar',          // Default locale
    ],
];

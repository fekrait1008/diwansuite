<?php
/**
 * DiwanSuite Contact Form API Endpoint
 * 
 * Handles contact form submissions with security measures:
 * - Rate limiting
 * - Input validation and sanitization
 * - Honeypot spam detection
 * - CORS support
 * - Email delivery
 */

// Define API access constant
define('DIWANSUITE_API', true);

// Load configuration and security utilities
$config = require __DIR__ . '/lib/config.php';
require __DIR__ . '/lib/contact-security.php';

// Initialize security handler
$security = new ContactSecurity($config);

// Set response headers
header('Content-Type: application/json; charset=utf-8');
$security->setCorsHeaders();

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode([
        'success' => false,
        'error' => 'Method not allowed',
        'code' => 'METHOD_NOT_ALLOWED'
    ]);
    exit;
}

// Get client IP for rate limiting
$clientIp = $security->getClientIp();

// Check rate limit
if (!$security->checkRateLimit($clientIp)) {
    $security->logEvent('rate_limit_exceeded', ['ip' => $clientIp]);
    http_response_code(429);
    echo json_encode([
        'success' => false,
        'error' => 'Too many requests. Please try again later.',
        'code' => 'RATE_LIMITED',
        'retry_after' => $config['security']['rate_limit_window']
    ]);
    exit;
}

// Parse request body
$contentType = $_SERVER['CONTENT_TYPE'] ?? '';
$input = [];

if (stripos($contentType, 'application/json') !== false) {
    $rawInput = file_get_contents('php://input');
    $input = json_decode($rawInput, true) ?? [];
} else {
    $input = $_POST;
}

// Check honeypot
if (!$security->checkHoneypot($input)) {
    $security->logEvent('honeypot_triggered', ['ip' => $clientIp]);
    // Return success to fool bots
    echo json_encode(['success' => true]);
    exit;
}

// Check submission timing (if timestamp provided)
$timestamp = isset($input['_timestamp']) ? (int)$input['_timestamp'] : null;
if (!$security->checkSubmissionTiming($timestamp)) {
    $security->logEvent('timing_check_failed', ['ip' => $clientIp, 'elapsed' => time() - $timestamp]);
    // Return success to fool bots
    echo json_encode(['success' => true]);
    exit;
}

// Validate required fields
$errors = [];

// Name validation
$name = $security->sanitize($input['name'] ?? '');
if (empty($name)) {
    $errors['name'] = 'Name is required';
} elseif (mb_strlen($name, 'UTF-8') < 2) {
    $errors['name'] = 'Name must be at least 2 characters';
} elseif (mb_strlen($name, 'UTF-8') > 100) {
    $errors['name'] = 'Name must be less than 100 characters';
}

// Email validation
$email = trim($input['email'] ?? '');
if (empty($email)) {
    $errors['email'] = 'Email is required';
} elseif (!$security->validateEmail($email)) {
    $errors['email'] = 'Please enter a valid email address';
}

// Phone validation (optional)
$phone = trim($input['phone'] ?? '');
if (!empty($phone) && !$security->validatePhone($phone)) {
    $errors['phone'] = 'Please enter a valid phone number';
}

// Subject validation
$subject = $security->sanitize($input['subject'] ?? '');
if (empty($subject)) {
    $errors['subject'] = 'Subject is required';
} elseif (mb_strlen($subject, 'UTF-8') < 3) {
    $errors['subject'] = 'Subject must be at least 3 characters';
} elseif (mb_strlen($subject, 'UTF-8') > 200) {
    $errors['subject'] = 'Subject must be less than 200 characters';
}

// Message validation
$message = $security->sanitize($input['message'] ?? '');
if (empty($message)) {
    $errors['message'] = 'Message is required';
} elseif (!$security->validateMessage($message)) {
    $errors['message'] = 'Message must be between 10 and 5000 characters';
}

// Spam check
if (!empty($message) && !$security->checkSpamPatterns($message)) {
    $security->logEvent('spam_detected', ['ip' => $clientIp]);
    $errors['message'] = 'Your message appears to contain spam content';
}

// Return validation errors
if (!empty($errors)) {
    http_response_code(422);
    echo json_encode([
        'success' => false,
        'error' => 'Validation failed',
        'code' => 'VALIDATION_ERROR',
        'errors' => $errors
    ]);
    exit;
}

// Prepare email
$emailSubject = $config['email']['subject_prefix'] . ' ' . $subject;
$emailBody = <<<EMAIL
New contact form submission from DiwanSuite website:

Name: {$name}
Email: {$email}
Phone: {$phone}
Subject: {$subject}

Message:
{$message}

---
Submitted at: {$submitTime}
IP Address: {$clientIp}
EMAIL;

$submitTime = date('Y-m-d H:i:s T');
$emailBody = str_replace('{$submitTime}', $submitTime, $emailBody);

// Email headers
$headers = [
    'From' => $config['email']['from'],
    'Reply-To' => $email,
    'X-Mailer' => 'DiwanSuite Contact Form',
    'Content-Type' => 'text/plain; charset=UTF-8',
];

$headerString = '';
foreach ($headers as $key => $value) {
    $headerString .= "$key: $value\r\n";
}

// Send email
$mailSent = false;

if ($config['smtp']['enabled']) {
    // Use SMTP if configured
    // Note: For production, consider using PHPMailer or similar library
    // This is a basic implementation
    $mailSent = @mail(
        $config['email']['to'],
        $emailSubject,
        $emailBody,
        $headerString
    );
} else {
    // Use PHP mail()
    $mailSent = @mail(
        $config['email']['to'],
        $emailSubject,
        $emailBody,
        $headerString
    );
}

// Log the submission
$security->logEvent('contact_submission', [
    'name' => $name,
    'email' => $email,
    'subject' => $subject,
    'mail_sent' => $mailSent
]);

// Return response
if ($mailSent) {
    echo json_encode([
        'success' => true,
        'message' => 'Thank you for your message. We will get back to you soon.'
    ]);
} else {
    // Even if mail fails, don't expose this to the user in production
    if ($config['debug']) {
        http_response_code(500);
        echo json_encode([
            'success' => false,
            'error' => 'Failed to send email. Please try again later.',
            'code' => 'MAIL_ERROR'
        ]);
    } else {
        // In production, still return success but log the error
        $security->logEvent('mail_error', ['to' => $config['email']['to']]);
        echo json_encode([
            'success' => true,
            'message' => 'Thank you for your message. We will get back to you soon.'
        ]);
    }
}

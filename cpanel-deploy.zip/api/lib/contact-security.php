<?php
/**
 * DiwanSuite Contact Form Security Utilities
 * 
 * Provides CSRF protection, rate limiting, input validation,
 * and spam prevention for the contact form.
 */

// Prevent direct access
if (!defined('DIWANSUITE_API')) {
    http_response_code(403);
    exit('Direct access forbidden');
}

class ContactSecurity {
    private array $config;
    
    public function __construct(array $config) {
        $this->config = $config;
    }
    
    /**
     * Validate CORS origin
     */
    public function validateOrigin(): bool {
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        $allowedOrigins = $this->config['security']['allowed_origins'];
        
        // If no origins configured, allow same-origin only
        if (empty($allowedOrigins)) {
            return true; // Rely on same-origin policy
        }
        
        return in_array($origin, $allowedOrigins, true);
    }
    
    /**
     * Set CORS headers
     */
    public function setCorsHeaders(): void {
        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
        $allowedOrigins = $this->config['security']['allowed_origins'];
        
        if (empty($allowedOrigins) || in_array($origin, $allowedOrigins, true)) {
            if (!empty($origin)) {
                header("Access-Control-Allow-Origin: $origin");
            }
            header('Access-Control-Allow-Methods: POST, OPTIONS');
            header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
            header('Access-Control-Max-Age: 86400');
        }
    }
    
    /**
     * Check rate limit for an IP address
     */
    public function checkRateLimit(string $ip): bool {
        $storageDir = $this->config['paths']['rate_limit_storage'];
        
        if (!is_dir($storageDir)) {
            @mkdir($storageDir, 0755, true);
        }
        
        $file = $storageDir . '/' . md5($ip) . '.json';
        $now = time();
        $window = $this->config['security']['rate_limit_window'];
        $limit = $this->config['security']['rate_limit'];
        
        $data = ['requests' => [], 'blocked_until' => 0];
        
        if (file_exists($file)) {
            $content = @file_get_contents($file);
            if ($content) {
                $data = json_decode($content, true) ?: $data;
            }
        }
        
        // Check if IP is blocked
        if ($data['blocked_until'] > $now) {
            return false;
        }
        
        // Remove old requests outside the window
        $data['requests'] = array_filter($data['requests'], fn($t) => $t > ($now - $window));
        
        // Check if over limit
        if (count($data['requests']) >= $limit) {
            $data['blocked_until'] = $now + $window;
            @file_put_contents($file, json_encode($data));
            return false;
        }
        
        // Record this request
        $data['requests'][] = $now;
        @file_put_contents($file, json_encode($data));
        
        return true;
    }
    
    /**
     * Get remaining rate limit for an IP
     */
    public function getRateLimitRemaining(string $ip): int {
        $storageDir = $this->config['paths']['rate_limit_storage'];
        $file = $storageDir . '/' . md5($ip) . '.json';
        $limit = $this->config['security']['rate_limit'];
        
        if (!file_exists($file)) {
            return $limit;
        }
        
        $content = @file_get_contents($file);
        if (!$content) {
            return $limit;
        }
        
        $data = json_decode($content, true);
        if (!$data) {
            return $limit;
        }
        
        $now = time();
        $window = $this->config['security']['rate_limit_window'];
        $recentRequests = array_filter($data['requests'] ?? [], fn($t) => $t > ($now - $window));
        
        return max(0, $limit - count($recentRequests));
    }
    
    /**
     * Check honeypot field (should be empty)
     */
    public function checkHoneypot(array $data): bool {
        $field = $this->config['security']['honeypot_field'];
        return empty($data[$field] ?? '');
    }
    
    /**
     * Validate submission timing
     */
    public function checkSubmissionTiming(?int $timestamp): bool {
        if ($timestamp === null) {
            return true; // No timestamp provided, skip check
        }
        
        $minTime = $this->config['security']['min_submission_time'];
        $elapsed = time() - $timestamp;
        
        return $elapsed >= $minTime;
    }
    
    /**
     * Sanitize input string
     */
    public function sanitize(string $input): string {
        // Remove null bytes
        $input = str_replace("\0", '', $input);
        // Trim whitespace
        $input = trim($input);
        // Convert special characters to HTML entities
        $input = htmlspecialchars($input, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        
        return $input;
    }
    
    /**
     * Validate email address
     */
    public function validateEmail(string $email): bool {
        $email = trim($email);
        
        if (empty($email)) {
            return false;
        }
        
        // Basic format validation
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return false;
        }
        
        // Check for suspicious patterns
        $suspicious = [
            '/\+.*\+/', // Multiple plus signs
            '/@.*@/',   // Multiple @ signs (already caught by filter_var, but extra safety)
        ];
        
        foreach ($suspicious as $pattern) {
            if (preg_match($pattern, $email)) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Validate phone number (international format)
     */
    public function validatePhone(string $phone): bool {
        $phone = trim($phone);
        
        if (empty($phone)) {
            return true; // Phone is optional
        }
        
        // Remove common formatting characters
        $cleaned = preg_replace('/[\s\-\(\)\.]/', '', $phone);
        
        // Should be digits only, optionally starting with +
        if (!preg_match('/^\+?[0-9]{7,15}$/', $cleaned)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Validate message content
     */
    public function validateMessage(string $message, int $minLength = 10, int $maxLength = 5000): bool {
        $message = trim($message);
        $length = mb_strlen($message, 'UTF-8');
        
        return $length >= $minLength && $length <= $maxLength;
    }
    
    /**
     * Check for spam patterns in content
     */
    public function checkSpamPatterns(string $content): bool {
        $spamPatterns = [
            '/\b(viagra|cialis|casino|lottery|winner|congratulations|click here|free money)\b/i',
            '/https?:\/\/[^\s]{50,}/i', // Very long URLs
            '/<[^>]*script/i', // Script tags
            '/\[url=/i', // BBCode links
        ];
        
        foreach ($spamPatterns as $pattern) {
            if (preg_match($pattern, $content)) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Get client IP address
     */
    public function getClientIp(): string {
        $headers = [
            'HTTP_CF_CONNECTING_IP', // Cloudflare
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_REAL_IP',
            'REMOTE_ADDR',
        ];
        
        foreach ($headers as $header) {
            if (!empty($_SERVER[$header])) {
                $ips = explode(',', $_SERVER[$header]);
                $ip = trim($ips[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }
        
        return '0.0.0.0';
    }
    
    /**
     * Log security event
     */
    public function logEvent(string $type, array $data = []): void {
        if (!$this->config['debug']) {
            return;
        }
        
        $logDir = $this->config['paths']['logs'];
        if (!is_dir($logDir)) {
            @mkdir($logDir, 0755, true);
        }
        
        $logFile = $logDir . '/security_' . date('Y-m-d') . '.log';
        $entry = [
            'timestamp' => date('c'),
            'type' => $type,
            'ip' => $this->getClientIp(),
            'data' => $data,
        ];
        
        @file_put_contents($logFile, json_encode($entry) . "\n", FILE_APPEND | LOCK_EX);
    }
}

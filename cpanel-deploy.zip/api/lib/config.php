<?php
/**
 * DiwanSuite API Configuration
 * 
 * Environment-aware configuration for cPanel deployment.
 * Reads from environment variables with sensible defaults.
 */

// Prevent direct access
if (!defined('DIWANSUITE_API')) {
    http_response_code(403);
    exit('Direct access forbidden');
}

// Load environment variables from .env if available (development)
$envFile = __DIR__ . '/../../../.env';
if (file_exists($envFile)) {
    $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        if (strpos($line, '=') !== false) {
            list($name, $value) = explode('=', $line, 2);
            $name = trim($name);
            $value = trim($value, " \t\n\r\0\x0B\"'");
            if (!getenv($name)) {
                putenv("$name=$value");
            }
        }
    }
}

// Configuration constants
return [
    // Email settings
    'email' => [
        'to' => getenv('CONTACT_EMAIL') ?: 'info@diwansuite.com',
        'from' => getenv('MAIL_FROM') ?: 'noreply@diwansuite.com',
        'subject_prefix' => '[DiwanSuite Contact]',
    ],
    
    // Security settings
    'security' => [
        'rate_limit' => (int)(getenv('RATE_LIMIT_PER_HOUR') ?: 10),
        'rate_limit_window' => 3600, // 1 hour in seconds
        'honeypot_field' => 'website', // Hidden field to catch bots
        'min_submission_time' => 3, // Minimum seconds between page load and submit
        'allowed_origins' => array_filter(explode(',', getenv('ALLOWED_ORIGINS') ?: '')),
    ],
    
    // SMTP settings (optional, falls back to PHP mail())
    'smtp' => [
        'enabled' => (bool)getenv('SMTP_HOST'),
        'host' => getenv('SMTP_HOST') ?: '',
        'port' => (int)(getenv('SMTP_PORT') ?: 587),
        'username' => getenv('SMTP_USERNAME') ?: '',
        'password' => getenv('SMTP_PASSWORD') ?: '',
        'encryption' => getenv('SMTP_ENCRYPTION') ?: 'tls',
    ],
    
    // File paths
    'paths' => [
        'logs' => __DIR__ . '/../../../logs',
        'rate_limit_storage' => sys_get_temp_dir() . '/diwansuite_rate_limits',
    ],
    
    // Debug mode
    'debug' => (bool)(getenv('APP_DEBUG') ?: false),
];

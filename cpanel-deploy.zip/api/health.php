<?php
/**
 * DiwanSuite Health Check Endpoint
 * 
 * Simple health check for monitoring and deployment verification.
 * Returns service status and basic diagnostics.
 */

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, no-store, must-revalidate');

// Basic checks
$checks = [
    'php' => [
        'status' => 'ok',
        'version' => PHP_VERSION,
    ],
    'mail' => [
        'status' => function_exists('mail') ? 'ok' : 'unavailable',
    ],
    'json' => [
        'status' => function_exists('json_encode') ? 'ok' : 'unavailable',
    ],
    'mbstring' => [
        'status' => function_exists('mb_strlen') ? 'ok' : 'unavailable',
    ],
];

// Check if temp directory is writable (for rate limiting)
$tempDir = sys_get_temp_dir();
$checks['temp_writable'] = [
    'status' => is_writable($tempDir) ? 'ok' : 'error',
    'path' => $tempDir,
];

// Overall status
$allOk = true;
foreach ($checks as $check) {
    if ($check['status'] === 'error') {
        $allOk = false;
        break;
    }
}

$response = [
    'status' => $allOk ? 'healthy' : 'degraded',
    'timestamp' => date('c'),
    'service' => 'DiwanSuite API',
    'version' => '1.0.0',
    'checks' => $checks,
];

http_response_code($allOk ? 200 : 503);
echo json_encode($response, JSON_PRETTY_PRINT);
